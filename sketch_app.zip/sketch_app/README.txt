Sketch Studio (Single-file HTML App)
=====================================

How to use
----------
1) Open `index.html` in any modern desktop browser (Chrome, Edge, Firefox). 
   - All image processing happens in your browser. No internet or server required.

2) Replace tutorial videos
   In the code, search for `assets/tutorial_beginner.mp4` etc. Replace with your own MP4 file paths
   or upload videos to your hosting and use full URLs.

3) Pricing
   - The price is estimated from paper size, medium, urgency, and image "edge complexity".
   - Adjust base price in the code: search for `let base = 1800;` (PKR, A4).

4) Build a ZIP
   - Windows: Right-click the `sketch_app` folder -> Send to -> Compressed (zipped) folder.
   - Mac: Right-click the folder -> Compress "sketch_app".
   - Android (Files app) or iOS (Files): Long-press folder -> Compress.

5) Deploy as a web app
   - Just upload `index.html` to any static hosting (Netlify, GitHub Pages, Vercel, etc.).
   - Or double-click `index.html` to run locally.

Made on: 2025-08-24
